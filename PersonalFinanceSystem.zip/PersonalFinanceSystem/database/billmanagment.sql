/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.5.62 : Database - billmanagement
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`billmanagement` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `billmanagement`;

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `CateId` int(11) NOT NULL AUTO_INCREMENT,
  `CaType` char(10) DEFAULT NULL,
  `CaName` char(10) DEFAULT NULL,
  PRIMARY KEY (`CateId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `category` */

insert  into `category`(`CateId`,`CaType`,`CaName`) values (1,'1','生活消费'),(2,'0','工作收入');

/*Table structure for table `incomeandexpenses` */

DROP TABLE IF EXISTS `incomeandexpenses`;

CREATE TABLE `incomeandexpenses` (
  `InExId` int(11) NOT NULL AUTO_INCREMENT,
  `InType` char(10) DEFAULT NULL,
  `InDate` char(20) DEFAULT NULL,
  `Person` char(10) DEFAULT NULL,
  `Money` char(10) DEFAULT NULL,
  `CateId` int(11) DEFAULT NULL,
  `InExplain` char(30) DEFAULT NULL,
  PRIMARY KEY (`InExId`),
  KEY `CateId` (`CateId`),
  CONSTRAINT `incomeandexpenses_ibfk_1` FOREIGN KEY (`CateId`) REFERENCES `category` (`CateId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `incomeandexpenses` */

insert  into `incomeandexpenses`(`InExId`,`InType`,`InDate`,`Person`,`Money`,`CateId`,`InExplain`) values (1,'0','2020年10月32日','我','3000',2,'账户管理'),(2,'1','2020年10月30日','我 家人','4',1,'早餐');

/*Table structure for table `major` */

DROP TABLE IF EXISTS `major`;

CREATE TABLE `major` (
  `majorId` char(10) NOT NULL,
  `majorName` char(10) DEFAULT NULL,
  `majorExplain` char(30) DEFAULT NULL,
  PRIMARY KEY (`majorId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `major` */

/*Table structure for table `project` */

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `ProId` int(11) NOT NULL AUTO_INCREMENT,
  `CateId` int(11) DEFAULT NULL,
  `ProName` char(10) DEFAULT NULL,
  PRIMARY KEY (`ProId`),
  KEY `CateId` (`CateId`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`CateId`) REFERENCES `category` (`CateId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `project` */

insert  into `project`(`ProId`,`CateId`,`ProName`) values (1,2,'工资'),(7,1,'餐饮'),(8,1,'交通费'),(9,2,'写作');

/*Table structure for table `userbill` */

DROP TABLE IF EXISTS `userbill`;

CREATE TABLE `userbill` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` char(10) DEFAULT NULL,
  `UserPassWord` char(10) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `userbill` */

insert  into `userbill`(`UserId`,`UserName`,`UserPassWord`) values (1,'admin','123456'),(2,'jiejie','123'),(3,'wanden','666');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
