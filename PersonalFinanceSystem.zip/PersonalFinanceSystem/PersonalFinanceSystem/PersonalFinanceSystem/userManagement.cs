﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PersonalFinanceSystem
{
    public partial class userManagement : Form
    {
        public userManagement()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void userManagement_Load(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            #region 查询
            //创建命令
            string sql = "select * from UserBill";//执行语句
            MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
            //执行命令--读取数据
            MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
            listBox1.Items.Add(string.Format("编号\t用户名\t密码"));
            while (reader.Read())//每次读一行显示在集合中
            {
                
                listBox1.Items.Add(string.Format("{0}\t{1}\t{2}", reader[0], reader[1], reader[2]));
            }
            #endregion
        }

        private void button1_Click(object sender, EventArgs e)
        {
         #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            #region 插入
            string userName = textBox1.Text;
            string passWord = textBox2.Text;
            MySqlCommand cmd = new MySqlCommand("insert into UserBill set UserName=@un , UserPassWord=@pwd", conn);
            cmd.Parameters.AddWithValue("un", userName);//添加值
            cmd.Parameters.AddWithValue("pwd", passWord);
            //执行语句
            cmd.ExecuteNonQuery();
            #endregion
            listBox1.Items.Clear();
            #region 查询
            //创建命令
            string sql = "select * from UserBill";//执行语句
            MySqlCommand cmdl = new MySqlCommand(sql, conn);//创建Command对象
            //执行命令--读取数据
            MySqlDataReader reader = cmdl.ExecuteReader();//创建MySqlDataReader对象
           // listBox1.Items.Add(string.Format("编号\t用户名\t密码"));
            while (reader.Read())//每次读一行显示在集合中
            {
                listBox1.Items.Add(string.Format("{0}\t{1}\t{2}", reader[0], reader[1], reader[2]));
            }
            #endregion

        }
    }
}
