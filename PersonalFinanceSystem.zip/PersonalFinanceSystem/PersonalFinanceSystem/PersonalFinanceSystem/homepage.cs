﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonalFinanceSystem
{
    public partial class homepage : Form
    {
        public homepage()
        {
            InitializeComponent();
        }

        private void homepage_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            incomeExpenditure stu = new incomeExpenditure();
            stu.Show();
        }

        private void 收支管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 添加收支PCtrlPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            incomeExpenditure stu = new incomeExpenditure();
            stu.Show();
        }

        private void 退出XCtrlXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 stu = new Form1();
            stu.Show();
        }

        private void 添加收支项目ICtrlIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InExaccount stu = new InExaccount();
            stu.Show();
        }

        private void 关于ACtrlAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aboutUs stu = new aboutUs();
            stu.Show();
        }

        private void 统计查询CCtrlCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statisticalQuery stu = new statisticalQuery();
            stu.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            statisticalQuery stu = new statisticalQuery();
            stu.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            InExaccount stu = new InExaccount();
            stu.Show();
        }

        private void 用户管理UCtrlUToolStripMenuItem_Click(object sender, EventArgs e)
        {
            userManagement stu = new userManagement();
            stu.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            userManagement stu = new userManagement();
            stu.Show();
        }
    }
}
