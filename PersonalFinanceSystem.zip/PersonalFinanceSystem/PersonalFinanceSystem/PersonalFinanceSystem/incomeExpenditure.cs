﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PersonalFinanceSystem
{
    public partial class incomeExpenditure : Form
    {
        public incomeExpenditure()
        {
            InitializeComponent();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            //获取收入类型
            string shouruleixing="";
            if (shouRu.Checked)
            {
                shouruleixing = "0";
            }
            else
            {
                shouruleixing = "1";

            }
            //获取收入类别
            string shouruleibie = "";
            if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }
            //获取类别编号
            MySqlCommand cmd2 = new MySqlCommand("SELECT CateId FROM category WHERE CaName = @lb", conn);
            cmd2.Parameters.AddWithValue("lb", shouruleibie);
            MySqlDataReader reader2 = cmd2.ExecuteReader();//创建MySqlDataReader对象
            int liebieid = 0;
            while (reader2.Read())//每次读一行显示在集合中
            {
                liebieid = Convert.ToInt32(reader2[0]);
            }
            reader2.Close();
            //获取日期
            string date = "";
            if (rQ.SelectedIndex != -1)
            {
                date = rQ.SelectedItem.ToString();
            }
            else
            {
                rQ.SelectedIndex = 0;
            }
            //获取说明
            string shuoming = "";
            shuoming = shuoMing.Text;
            //获取收支人
            string shouzhiren = "";
            CheckBox[] person = new CheckBox[] { My, Family, Relative, Friend, Classmate, Other };
            for (int i = 0; i < person.Length; i++)
            {
                if (person[i].Checked)
                {
                    shouzhiren += person[i].Text + " ";
                }
            }
            //获取金额
            string jiner = "";
            jiner = jinEr.Text;
            //导入数据表
            #region 插入
            MySqlCommand cmdd = new MySqlCommand("insert into incomeAndExpenses set InType=@ty,InDate=@dat,Person=@per,Money=@mon,InExplain=@exp,CateId=@cate", conn);
            cmdd.Parameters.AddWithValue("ty", shouruleixing);//添加值
            cmdd.Parameters.AddWithValue("dat", date);
            cmdd.Parameters.AddWithValue("per", shouzhiren);
            cmdd.Parameters.AddWithValue("mon", jiner);
            cmdd.Parameters.AddWithValue("exp", shuoming);
            cmdd.Parameters.AddWithValue("cate", liebieid);
            //执行语句
            cmdd.ExecuteNonQuery();
            this.Close();
            #endregion
        }

        private void incomeExpenditure_Load(object sender, EventArgs e)
        {
            
   



        }
        //实时统计备注
        private void chenge()
        {
            //获取收入类型
            string shouruleixing;
            if (shouRu.Checked)
            {
                shouruleixing = "收入";
            }
            else
            {
                shouruleixing = "支出";

            }
            //获取收入类别
            string shouruleibie="";
            if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }

            //获取日期
            string date="";
            if (rQ.SelectedIndex != -1)
            {
                date = rQ.SelectedItem.ToString();
            }
            else
            {
                rQ.SelectedIndex = 0;
            }
            //获取说明
            string shuoming = "";
            shuoming = shuoMing.Text;
            //获取收支项目

            string shouzhixiangmu = "";
            if (shouZhiXiangMu.SelectedItems.Count == 0)
            {
                return;
            }
            else
            {                        
                    shouzhixiangmu = shouZhiXiangMu.SelectedItem.ToString();
                
               
            }

            //获取收支人
            string shouzhiren = "";
            CheckBox[] person = new CheckBox[] { My, Family, Relative, Friend, Classmate, Other };
            for (int i = 0; i < person.Length; i++)
            {
                if (person[i].Checked)
                {
                    shouzhiren += person[i].Text + " ";
                }
            }
            //获取金额
            string jiner = "";
            jiner = jinEr.Text;
            //合并备注
            string remark = "";
            remark += "要保存的信息为：\n";
            remark += shouruleibie + "-" + shouzhixiangmu + "\n";
            remark += "日 期：" + date + "\n";
            remark += "说 明：" + shuoming + "\n";
            remark += "收支人：" + shouzhiren + "\n";
            remark += "金 额：" + jiner;
            beiZhu.Text = remark;
        }
        private void shouRu_CheckedChanged(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            shouRuLeiBie.Items.Clear();
      
            //创建命令
            string sql = "SELECT CaName FROM Category WHERE Catype='0'";//执行语句
            MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                           //执行命令--读取数据
            MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
            shouRuLeiBie.Items.Clear();
            while (reader.Read())//每次读一行显示在集合中
            {
                shouRuLeiBie.Items.Add(reader[0]);
            }
            shouRuLeiBie.SelectedIndex = 0;
            reader.Close();
            //获取选中类别名称
            string shouruleibie = "";
           if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }
            shouZhiXiangMu.Items.Clear();
            //获取类别编号
            MySqlCommand cmd2 = new MySqlCommand("SELECT CateId FROM category WHERE CaName = @lb", conn);
            cmd2.Parameters.AddWithValue("lb", shouruleibie);
            MySqlDataReader reader2 = cmd2.ExecuteReader();//创建MySqlDataReader对象
            int liebieid = 0;
            while (reader2.Read())//每次读一行显示在集合中
            {
                liebieid = Convert.ToInt32(reader2[0]);
            }
            //shouZhiXiangMu.Items.Add(shouruleibie);
           // shouZhiXiangMu.Items.Add(liebieid);
            reader2.Close();
            //导入项目
            MySqlCommand cmd3 = new MySqlCommand("SELECT proName FROM project WHERE CateId = @idd", conn);//创建Command对象
            cmd3.Parameters.AddWithValue("idd", liebieid);//添加值
            MySqlDataReader reader3 = cmd3.ExecuteReader();//创建MySqlDataReader对象
            //shouZhiXiangMu.Items.Clear();
            while (reader3.Read())
            {
                shouZhiXiangMu.Items.Add(reader3[0]);
            }
            reader3.Close();
            chenge();
        }

        private void zhiChu_CheckedChanged(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            shouRuLeiBie.Items.Clear();

            //创建命令
            string sql = "SELECT CaName FROM Category WHERE Catype='1'";//执行语句
            MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                           //执行命令--读取数据
            MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
            shouRuLeiBie.Items.Clear();
            while (reader.Read())//每次读一行显示在集合中
            {
                shouRuLeiBie.Items.Add(reader[0]);
            }
            shouRuLeiBie.SelectedIndex = 0;
            reader.Close();
            //获取选中类别名称
            string shouruleibie = "";
            if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }
            shouZhiXiangMu.Items.Clear();
            //获取类别编号
            MySqlCommand cmd2 = new MySqlCommand("SELECT CateId FROM category WHERE CaName = @lb", conn);
            cmd2.Parameters.AddWithValue("lb", shouruleibie);
            MySqlDataReader reader2 = cmd2.ExecuteReader();//创建MySqlDataReader对象
            int liebieid = 0;
            while (reader2.Read())//每次读一行显示在集合中
            {
                liebieid = Convert.ToInt32(reader2[0]);
            }
            reader2.Close();
            //导入项目
            MySqlCommand cmd3 = new MySqlCommand("SELECT proName FROM project WHERE CateId = @idd", conn);//创建Command对象
            cmd3.Parameters.AddWithValue("idd", liebieid);//添加值
            MySqlDataReader reader3 = cmd3.ExecuteReader();//创建MySqlDataReader对象
            //shouZhiXiangMu.Items.Clear();
            while (reader3.Read())
            {
                shouZhiXiangMu.Items.Add(reader3[0]);
            }
            reader3.Close();
            chenge();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void shouZhiXiangMu_SelectedIndexChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void shuoMing_TextChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void My_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void Family_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void Relative_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void Classmate_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void Other_CheckedChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void shouRuLeiBie_SelectedIndexChanged(object sender, EventArgs e)
        {
            chenge();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
