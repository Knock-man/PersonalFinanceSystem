﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PersonalFinanceSystem
{
    public partial class InExaccount : Form
    {
        public InExaccount()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //获取项目名称
            string projectName = textBox1.Text;
            string shouruleibie = "";
            if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }
            listBox1.Items.Clear();
            listBox1.Items.Add("项目名称：" + projectName);
            listBox1.Items.Add("类别：" + shouruleibie);
            tabControl1.SelectedIndex = 1;

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            //获取项目名称
            string projectName = textBox1.Text;
            string shouruleibie = "";
            //获取类别
            if (shouRuLeiBie.SelectedIndex != -1)
            {
                shouruleibie = shouRuLeiBie.SelectedItem.ToString();
            }
            else
            {
                shouRuLeiBie.SelectedIndex = 0;
            }
            //获取类别编号
            MySqlCommand cmd = new MySqlCommand("SELECT CateId FROM category WHERE CaName=@leibie", conn);
            cmd.Parameters.AddWithValue("leibie", shouruleibie);
            MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
            int liebieid=0;
            while (reader.Read())//每次读一行显示在集合中
            {
                liebieid =Convert.ToInt32(reader[0]);
            }
            reader.Close();
            //插入新项目数据
            #region 插入
            MySqlCommand cmdd = new MySqlCommand("insert into Project set CateId=@idd , ProName=@un", conn);
    
            cmdd.Parameters.AddWithValue("idd", liebieid);//添加值
            cmdd.Parameters.AddWithValue("un", projectName);
            //执行语句
            cmdd.ExecuteNonQuery();
            #endregion
            this.Close();




        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
          
            //判断是收入还是支出
            if (radioButton1.Checked)//收入
            {
                #region 查询
                //创建命令
                string sql = "SELECT caName FROM Category WHERE Catype='0'";//执行语句
                MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                               //执行命令--读取数据
                MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
                shouRuLeiBie.Items.Clear();
                while (reader.Read())//每次读一行显示在集合中
                {
                    shouRuLeiBie.Items.Add(reader[0]);
                }
                shouRuLeiBie.SelectedIndex = 0;
                #endregion
            }
            else//支出
            {
                //创建命令
                string sql = "SELECT caName FROM Category WHERE Catype='1'";//执行语句
                MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                               //执行命令--读取数据
                MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
                shouRuLeiBie.Items.Clear();
                while (reader.Read())//每次读一行显示在集合中
                {
                    shouRuLeiBie.Items.Add(reader[0]);
                }
                shouRuLeiBie.SelectedIndex = 0;
            }
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion

            //判断是收入还是支出
            if (radioButton1.Checked)//收入
            {
                #region 查询
                //创建命令
                string sql = "SELECT caName FROM Category WHERE Catype='0'";//执行语句
                MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                               //执行命令--读取数据
                MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
                shouRuLeiBie.Items.Clear();
                while (reader.Read())//每次读一行显示在集合中
                {
                    shouRuLeiBie.Items.Add(reader[0]);
                }
                shouRuLeiBie.SelectedIndex = 0;
                #endregion
            }
            else//支出
            {
                //创建命令
                string sql = "SELECT caName FROM Category WHERE Catype='1'";//执行语句
                MySqlCommand cmd = new MySqlCommand(sql, conn);//创建Command对象
                                                               //执行命令--读取数据
                MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
                shouRuLeiBie.Items.Clear();
                while (reader.Read())//每次读一行显示在集合中
                {
                    shouRuLeiBie.Items.Add(reader[0]);
                }
                shouRuLeiBie.SelectedIndex = 0;
            }

        }

        private void InExaccount_Load(object sender, EventArgs e)
        {

        }
    }
}

