﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PersonalFinanceSystem
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            if (userName.Text != ""||passWord.Text!=""||verificationCode.Text!="")
            {
                userName.Text = "";
                passWord.Text = "";
                verificationCode.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void userName_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            #region 查询
            //验空
            if (userName.Text == "")
            {
                MessageBox.Show("用户名不能为空", "用户登录", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (passWord.Text == "")
            {
                MessageBox.Show("密码不能为空", "用户登录", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (verificationCode.Text == "")
            {
                MessageBox.Show("验证不能为空", "用户登录", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (verificationCode.Text != label5.Text)
            {
                MessageBox.Show("验证码错误，请重新输入", "用户登录", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }else{
                //创建命令
                string username = userName.Text;//获取输入用户名
                string password = passWord.Text;//获取输入密码
                string sqlSel = "select count(*) from UserBill where UserName = '" + username + "' and UserPassWord = '" + password + "'";//查询语句
                MySqlCommand com = new MySqlCommand(sqlSel, conn);
                //判断executeScalar方法返回的参数是否大于0，大于0表示查找有数据
                if (Convert.ToInt32(com.ExecuteScalar()) > 0)
                {
                    MessageBox.Show("欢迎加入个人理财系!", "登录成功", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    homepage home = new homepage();
                    this.Hide();
                    home.Show();
                }
                else
                {
                    MessageBox.Show("账户或者密码错误！请重新输入", "用户登录", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                #endregion
            }

        }



        private void Form1_Load(object sender, EventArgs e)
        {
            //this.IsMdiContainer = true;
            Random rd = new Random();
            label5.Text =Convert.ToString(rd.Next(1000, 10000));
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
