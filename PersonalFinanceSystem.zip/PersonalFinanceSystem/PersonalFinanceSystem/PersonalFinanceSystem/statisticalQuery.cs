﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PersonalFinanceSystem
{
    public partial class statisticalQuery : Form
    {
        public statisticalQuery()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string xiangmuName = textBox1.Text;
            #region 连接数据库
            //定义连接字符串
            string connStr = "Database=BillManagement;Data Source=127.0.0.1;port=3306;User Id=root;";
            MySqlConnection conn = new MySqlConnection(connStr);//创建Connection对象
            conn.Open();//打开数据库
            #endregion
            listBox1.Items.Clear();
            #region 查询
            //创建命令
            MySqlCommand cmd = new MySqlCommand("SELECT InDate,Person,Money,InExplain,caName FROM incomeAndExpenses,project,category WHERE incomeAndExpenses.CateId=project.CateId AND incomeAndExpenses.CateId=category.cateid AND project.ProName=@xmu;", conn);//创建Command对象
            cmd.Parameters.AddWithValue("xmu", xiangmuName);//添加值
            //执行命令--读取数据
            MySqlDataReader reader = cmd.ExecuteReader();//创建MySqlDataReader对象
            while (reader.Read())//每次读一行显示在集合中
            {
                listBox1.Items.Add(string.Format("       日期\t收支人\t金额\t说明   \t收支类型\n"));
                listBox1.Items.Add(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", reader[0], reader[1], reader[2],reader[3],reader[4]));
            }
            reader.Close();
            #endregion


        }

        private void statisticalQuery_Load(object sender, EventArgs e)
        {

        }
    }
}
