﻿namespace PersonalFinanceSystem
{
    internal class tabPage2
    {
    }
}